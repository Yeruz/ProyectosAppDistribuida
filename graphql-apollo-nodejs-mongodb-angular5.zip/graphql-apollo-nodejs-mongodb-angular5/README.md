# graphql-apollo-nodejs-mongodb-angular5
Un simple Apollo + GraphQL + NodeJs + Express + MongoDB + Angular5 CRUD

Este proyecto muestra un ejemplo completo de una aplicación CRUD  basado en NodeJs, Angular 5 con Graphql API.



