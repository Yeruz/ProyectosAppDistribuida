package memoramacliente;

import java.awt.Color;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class Escuchar extends Thread {

    DataInputStream canalEntrada;
    String recibido;
    Tablero miTablero;
    ArrayList<Carta> myListaCartas;

    public Escuchar(DataInputStream canalEntrada) {
        this.canalEntrada = canalEntrada;
    }

    public void setMiTablero(Tablero miTablero) {
        this.miTablero = miTablero;
    }

    @Override
    public void run() {
        while (true) {
            try {
                recibido = canalEntrada.readUTF();
                System.out.println("" + recibido);

                switch (recibido) {
                    case "-2":
                        miTablero.setSoy(1);
                        miTablero.setEstado(1);
                        miTablero.getPuntuacionJ1().setOpaque(true);
                        miTablero.getPuntuacionJ1().setBackground(Color.WHITE);
                        miTablero.inicializarLetreroTurno();
                        System.out.println("Soy J1");
                        break;

                    case "-1":
                        miTablero.setSoy(2);
                        miTablero.setEstado(1);
                        miTablero.getPuntuacionJ2().setOpaque(true);
                        miTablero.getPuntuacionJ2().setBackground(Color.WHITE);
                        miTablero.inicializarLetreroTurno();
                        System.out.println("Soy J2");
                        break;

                    case "3":
                        miTablero.setEstado(0);
                        miTablero.getLetreroTurno().setText("El ganador es el jugador #1");
                        miTablero.getLetreroTurno().setForeground(Color.BLACK);
                        break;

                    case "4":
                        miTablero.setEstado(0);
                        miTablero.getLetreroTurno().setText("El ganador es el jugador #2");
                        miTablero.getLetreroTurno().setForeground(Color.BLACK);
                        break;

                    case "5":
                        miTablero.setEstado(0);
                        miTablero.getLetreroTurno().setText("ES EMPATE");
                        miTablero.getLetreroTurno().setForeground(Color.BLACK);
                        break;

                    default:
                        if (recibido.length() == 3) {
                            System.out.println("Recibido: " + recibido);
                            System.out.println("Volteadas: " + miTablero.getVolteadas());
                            switch (miTablero.getVolteadas()) {
                                case 0:
                                    miTablero.setVolteada1(miTablero.cambiaImagenCarta(recibido));
                                    miTablero.setVolteadas(miTablero.getVolteadas() + 1);
                                    break;
                                case 1:
                                    miTablero.setVolteada2(miTablero.cambiaImagenCarta(recibido));
                                    miTablero.setVolteadas(miTablero.getVolteadas() + 1);
                                    if (miTablero.getVolteada1().getRutaImagen().equals(miTablero.getVolteada2().getRutaImagen())) {
                                        miTablero.serverAcerto();
                                    } else {
                                        miTablero.serverFallo();
                                    }
                                    break;
                            }
                        } else if (recibido.length() > 100) {
                            String nombreTemp = "";
                            int contadorRutas = 0;
                            System.out.println("Mayor 100");
                            myListaCartas = miTablero.getListaCartas();
                            System.out.println("Tamaño Lista " + myListaCartas.size());
                            for (int x = 0; x < recibido.length(); x++) {
                                if (recibido.charAt(x) != '_') {
                                    nombreTemp += recibido.charAt(x);
                                } else {
                                    myListaCartas.get(contadorRutas).setRutaImagen(nombreTemp);
                                    nombreTemp = "";
                                    System.out.println("Guardado " + myListaCartas.get(contadorRutas).getRutaImagen()
                                            + " en el indice " + contadorRutas + " con el nombre de: "
                                            + myListaCartas.get(contadorRutas).getName());
                                    contadorRutas++;
                                }
                            }
                        }
                        break;
                }

            } catch (IOException ex) {
                System.err.println("Error al recibir de Server");
            }
        }
    }
}
