package memoramacliente;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class Tablero extends JFrame implements MouseListener {

    static int PUERTO = 3579;
    //String HOST = "localhost";
    String HOST;
    static Socket conexion;
    static DataInputStream canalEntrada;
    static DataOutputStream canalSalida;

    private String caraOculta = "src/img/oculta.png";
    private int numCartas, numPares;
    private Carta c;
    private ArrayList<Carta> listaCartas;
    private JLabel puntuacionJ1, puntuacionJ2, letreroTurno;

    String quieroEnviar;
    int estado = -3, miPuntuacion = 0, suPuntuacion = 0, volteadas = 0, soy;
    Carta volteada1 = null, volteada2 = null;
    boolean enviarEstado = false;
    private Timer miTimer;
    private final int segundos = 3;
    private int segundosT;

    public Tablero(int pares) {
        setTitle("Memorama Cliente");
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setBounds(600, 25, 550, 640);
        this.numPares = pares;
        this.numCartas = pares * 2;
        iniciarCliente();
    }

    public void componentes() {
        listaCartas = new ArrayList();

        int contador = 0;
        for (int i = 0; i < numCartas; i++) { //Crea Cartas            

            c = new Carta(((i - (contador * 4)) * 120) + 40, (contador * 120) + 20);
            if ((i + 1) % 4 == 0) {
                contador++;
            }
            c.addMouseListener(this);
            if (i < 10) {
                c.setName("C0" + i);
            } else {
                c.setName("C" + i);
            }
            c.setIcon(new ImageIcon(caraOculta));
            listaCartas.add(c);
            this.add(c);
        }

        letreroTurno = new JLabel();
        letreroTurno.setBounds(50, 500, 450, 35);
        Font auxFont = letreroTurno.getFont();
        letreroTurno.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 30));
        letreroTurno.setText("Esperando al Servidor...");
        letreroTurno.setHorizontalAlignment(JLabel.CENTER);
        this.add(letreroTurno);

        puntuacionJ1 = new JLabel();
        puntuacionJ1.setBounds(50, 550, 200, 35);
        puntuacionJ1.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 20));
        puntuacionJ1.setText("Jugador 1: 0");
        puntuacionJ1.setHorizontalAlignment(JLabel.CENTER);
        puntuacionJ1.setForeground(Color.RED);
        this.add(puntuacionJ1);

        puntuacionJ2 = new JLabel();
        puntuacionJ2.setBounds(300, 550, 200, 35);
        puntuacionJ2.setFont(new Font(auxFont.getFontName(), auxFont.getStyle(), 20));
        puntuacionJ2.setText("Jugador 2: 0");
        puntuacionJ2.setHorizontalAlignment(JLabel.CENTER);
        puntuacionJ2.setForeground(Color.BLUE);
        this.add(puntuacionJ2);

    }//Fin Componentes

    public void crearNuevoTimer() {
        miTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (segundosT == 0) {
                    volteadas = 0;
                    volteada1.setIcon(new ImageIcon(caraOculta));
                    volteada2.setIcon(new ImageIcon(caraOculta));
                    volteada1 = null;
                    volteada2 = null;
                    System.out.println("Nulizado Las Volteadas");
                    System.out.println("Finaliza turno del J" + estado);
                    actualizarLetreroTurno();
                    alternarEstado();
                    System.out.println("Ahora es el turno del J" + estado);
                    System.out.println("Quedan Volteadas: " + getVolteadas());

                    if (miPuntuacion + suPuntuacion == 800) {
                        elegirGanador();
                    }

                    miTimer.stop();
                } else if (segundosT > 0) {
                    System.out.println("Segundos: " + segundosT);
                    segundosT--;
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        switch (estado) {
            case 1:
                if (soy == 1 && volteadas != 2) {
                    quieroEnviar = me.getComponent().getName();
                    System.out.println("Envio: " + quieroEnviar);
                    turnoCliente();
                }
                break;

            case 2:
                if (soy == 2 && volteadas != 2) {
                    quieroEnviar = me.getComponent().getName();
                    System.out.println("Envio: " + quieroEnviar);
                    turnoCliente();
                }
                break;

        }
    }

    @Override
    public void mousePressed(MouseEvent me) {

    }

    @Override
    public void mouseReleased(MouseEvent me) {

    }

    @Override
    public void mouseEntered(MouseEvent me) {

    }

    @Override
    public void mouseExited(MouseEvent me) {

    }

    public void iniciarCliente() {

        try {
            HOST = JOptionPane.showInputDialog(null, "Ingrese la direccion del Servidor: ");
            //conexion = new Socket("10.127.127.1", PUERTO);
            conexion = new Socket(HOST, PUERTO);
            System.out.println("Host: " + HOST);

            System.out.println("Conexión establecida con el servidor...");

            componentes();

            canalSalida = new DataOutputStream(conexion.getOutputStream());

            canalEntrada = new DataInputStream(conexion.getInputStream());

            Escuchar mensajes = new Escuchar(canalEntrada);
            mensajes.setMiTablero(this);
            mensajes.start();
        } catch (IOException ex) {
            System.err.println("Error Iniciar Cliente");
        }

    }

    public void enviarAServer(String mensajeAEnviar) {
        try {
            canalSalida.writeUTF(mensajeAEnviar);
        } catch (IOException ex) {
            System.err.println("Error al enviar A Server");
        }
    }

    public void cerrarCliente() {
        System.out.println("Cerrando socket..");
        try {
            conexion.close();
        } catch (IOException ex) {
            System.err.println("Erro al cerrar Cliente");
        }
    }

    public boolean cartaDisponible(String nombreCarta) {
        boolean validado = false;

        for (int bc = 0; bc < listaCartas.size(); bc++) {
            if (nombreCarta.equals(listaCartas.get(bc).getName()) && !listaCartas.get(bc).isAcertada()) {
                if (volteadas == 1) {
                    if (listaCartas.get(bc) != volteada1) {
                        listaCartas.get(bc).colocaImagen();
                        volteada2 = listaCartas.get(bc);
                        volteadas++;
                        validado = true;
                        break;
                    }
                } else {
                    listaCartas.get(bc).colocaImagen();
                    volteada1 = listaCartas.get(bc);
                    volteadas++;
                    validado = true;
                    break;
                }
            }
        }
        return validado;
    }

    public Carta cambiaImagenCarta(String nombreCarta) {
        for (int bc = 0; bc < listaCartas.size(); bc++) {
            if (nombreCarta.equals(listaCartas.get(bc).getName())) {
                listaCartas.get(bc).colocaImagen();
                return listaCartas.get(bc);
            }
        }
        return null;
    }

    public void turnoCliente() {
        if (cartaDisponible(quieroEnviar)) {
            System.out.println("El cliente eligio: " + quieroEnviar);
            enviarAServer(quieroEnviar);

            if (volteadas == 2) {
                if (volteada1.getRutaImagen().equals(volteada2.getRutaImagen())) {
                    volteada1.ponerComoAcertada();
                    volteada2.ponerComoAcertada();
                    volteada1 = null;
                    volteada2 = null;
                    volteadas = 0;
                    aumentarmePuntos();
                    System.out.println("+100 puntos para Cliente");
                } else {
                    segundosT = segundos;
                    crearNuevoTimer();
                    miTimer.start();
                }
            }
        }
    }

    public void serverAcerto() {
        volteada1.ponerComoAcertada();
        volteada2.ponerComoAcertada();
        volteada1 = null;
        volteada2 = null;
        volteadas = 0;
        aumentarlePuntos();
        System.out.println("+100 puntos para Server");
    }

    public void serverFallo() {
        segundosT = segundos;
        crearNuevoTimer();
        miTimer.start();
    }

    public void actualizarLetreroPuntos() {
        if (soy == 1) {
            puntuacionJ1.setText("Jugador 1: " + miPuntuacion);
            puntuacionJ2.setText("Jugador 2: " + suPuntuacion);
        } else {
            puntuacionJ1.setText("Jugador 1: " + suPuntuacion);
            puntuacionJ2.setText("Jugador 2: " + miPuntuacion);
        }
    }

    public void inicializarLetreroTurno() {
        if (estado == 1) {
            letreroTurno.setText("Es el turno del jugador #1");
            letreroTurno.setForeground(Color.RED);
        } else if (estado == 2) {
            letreroTurno.setText("Es el turno del jugador #2");
            letreroTurno.setForeground(Color.BLUE);
        }
    }

    public void actualizarLetreroTurno() {
        if (estado == 1) {
            letreroTurno.setText("Es el turno del jugador #2");
            letreroTurno.setForeground(Color.BLUE);
        } else if (estado == 2) {
            letreroTurno.setText("Es el turno del jugador #1");
            letreroTurno.setForeground(Color.RED);
        }
    }

    public void alternarEstado() {
        System.out.println("Alternando Estado...");
        if (estado == 1) {
            estado = 2;
        } else if (estado == 2) {
            estado = 1;
        }
    }

    public void aumentarmePuntos() {
        miPuntuacion += 100;
        actualizarLetreroPuntos();
    }

    public void aumentarlePuntos() {
        suPuntuacion += 100;
        actualizarLetreroPuntos();
    }

    public ArrayList<Carta> getListaCartas() {
        return listaCartas;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getVolteadas() {
        return volteadas;
    }

    public void setVolteadas(int volteadas) {
        this.volteadas = volteadas;
    }

    public int getSoy() {
        return soy;
    }

    public void setSoy(int soy) {
        this.soy = soy;
    }

    public Carta getVolteada1() {
        return volteada1;
    }

    public void setVolteada1(Carta volteada1) {
        this.volteada1 = volteada1;
    }

    public Carta getVolteada2() {
        return volteada2;
    }

    public void setVolteada2(Carta volteada2) {
        this.volteada2 = volteada2;
    }

    public JLabel getPuntuacionJ1() {
        return puntuacionJ1;
    }

    public JLabel getPuntuacionJ2() {
        return puntuacionJ2;
    }

    public JLabel getLetreroTurno() {
        return letreroTurno;
    }

    public void elegirGanador() {
        int quienGano = 0;
        if (miPuntuacion == suPuntuacion) {
            letreroTurno.setText("EMPATE");
            quienGano = 5;
        } else {
            int eres;
            if (soy == 1) {
                eres = 2;
            } else {
                eres = 1;
            }
            if (miPuntuacion > suPuntuacion) {
                letreroTurno.setText("El ganador es el jugador #" + soy);
                quienGano = soy + 2;
            } else if (suPuntuacion > miPuntuacion) {
                letreroTurno.setText("El ganador es el jugador #" + eres);
                quienGano = soy + 2;
            }
        }
        letreroTurno.setForeground(Color.BLACK);
        enviarAServer("" + quienGano);
    }

}
