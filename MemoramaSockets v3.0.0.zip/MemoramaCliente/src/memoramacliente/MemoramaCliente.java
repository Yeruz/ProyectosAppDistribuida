package memoramacliente;

public class MemoramaCliente {

    public static void main(String[] args) {
        Tablero tablero = new Tablero(8);
        tablero.setVisible(true);
    }
}
