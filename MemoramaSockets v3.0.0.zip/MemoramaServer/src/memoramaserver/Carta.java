package memoramaserver;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Carta extends JButton {

    private String rutaImagen;
    private boolean acertada;

    public Carta(int posicionX, int posicionY) {
        this.setBounds(posicionX, posicionY, 100, 100);
        this.setBackground(Color.WHITE);
        this.setOpaque(true);
    }

    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    public void colocaImagen() {
        setIcon(new ImageIcon(rutaImagen));
    }

    public void ponerComoAcertada() {
        this.acertada = true;
    }

    public boolean isAcertada() {
        return acertada;
    }

}
